import React from 'react'

const Personal = () => {
  return (
    <div className='page_wrap'>
      <div className="container">
        <div className="personal">
          <div className="window">
            <img src="" alt="" />
            <h2>h2</h2>
          </div>
          <ul>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
          </ul>
          <div className="content">
            
          </div>
        </div>
      </div>
    </div>
  )
}

export default Personal