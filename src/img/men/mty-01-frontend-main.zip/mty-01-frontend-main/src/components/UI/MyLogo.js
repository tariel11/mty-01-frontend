import React from 'react'

const MyLogo = () => {
  return (
    <div>MyLogo</div>
  )
}

export default MyLogo